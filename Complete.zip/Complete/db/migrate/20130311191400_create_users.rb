class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :name
      t.string :email
      t.string :major
      t.string :experience
      t.string :graduation_date
      t.string :interests

      t.timestamps
    end
  end
end
