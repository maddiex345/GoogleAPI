Application for Pace University Entrepreneurship Lab
Julie Gauthier done with the help of railstutorial.org by Michael Hartl