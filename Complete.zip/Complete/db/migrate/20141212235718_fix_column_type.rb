class FixColumnType < ActiveRecord::Migration
  	def self.up
  		rename_column :users, :graduation_date, :date_entered_string
  		add_column :users, :graduation_date, :date

  		User.reset_column_information
  		User.find_each { |c| c.update_attribute(:graduation_date, c.date_entered_string) } 
  		remove_column :users, :date_entered_string
	end
end
